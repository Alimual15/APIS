document.getElementById('fetch-button').addEventListener('click', async () => {
    const name = document.getElementById('pokemon-name').value.toLowerCase();
    const pokemonInfoDiv = document.getElementById('pokemon-info');
    pokemonInfoDiv.innerHTML = ''; // Limpiar información previa

    try {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${name}`);
        if (!response.ok) {
            throw new Error('Pokémon no encontrado');
        }
        const data = await response.json();
        
        // Mostrar información del Pokémon
        pokemonInfoDiv.innerHTML = `
            <h2>${data.name.charAt(0).toUpperCase() + data.name.slice(1)}</h2>
            <img src="${data.sprites.front_default}" alt="${data.name}">
            <p>Altura: ${data.height}</p>
            <p>Peso: ${data.weight}</p>
        `;
    } catch (error) {
        pokemonInfoDiv.innerHTML = `<p class="error">${error.message}</p>`;
    }
});